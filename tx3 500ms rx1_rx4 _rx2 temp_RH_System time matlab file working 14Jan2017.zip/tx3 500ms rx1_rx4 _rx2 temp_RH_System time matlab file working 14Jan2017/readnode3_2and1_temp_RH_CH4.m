ser=serial('com7')
file = fopen('30Dec2016.txt','w');
fopen(ser)
while 1
read=fread(ser)
for n = 1:470
if read(n)==62 & read(n+1)==82 & read(n+11)==36
node3=read(n+15)
temperature_node3 = [read(n+23)*256+read(n+22)]/13
Humidity_node3 = [[[read(n+25)*256+read(n+24)]/1024]*100]
%Methane_node3_adc_count1 = [read(n+27)*256+read(n+26)]
Methane_node3_adc_count2 = [[read(n+27)*256+read(n+26)]*2]			% multiplication is needed as resistor devider is used at adc pin, actual sensor voltage = 2 x adc voltage 
methane_node3_adc_volts = Methane_node3_adc_count2*(3.3/1024)
if methane_node3_adc_volts <= 2.8
methane_node3_ppm = 0
else 
methane_node3_ppm = 43.131*exp(1.0418*methane_node3_adc_volts)
end 




node1=read(n+33)
temperature_node1 = [read(n+41)*256+read(n+40)]/13


fprintf(file,'Node %d',node3);
fprintf (file,' temperature is %2.2f C\n',temperature_node3);
fprintf (file,'Humidity is %2.2f percent\n',Humidity_node3);
fprintf (file,'Methane Concentration is %2.2f ppm\n',methane_node3_ppm);

fprintf(file,'Node %d',node1);
fprintf (file,' temperature is %2.2f C\n',temperature_node1);


end


if read(n)==62 & read(n+1)==82 & read(n+11)==18

node2=read(n+15)
temperature_node2 = [read(n+23)*256+read(n+22)]/13


fprintf(file,'Node %d',node2);
fprintf (file,' temperature is %2.2f C\n',temperature_node2);

end

end

%save 17Dec2016.txt formatted_temperature -ascii -append
end