ser=serial('com7')
file = fopen('27Dec2016.txt','w');
fopen(ser)
while 1
read=fread(ser)
for n = 1:470
if read(n)==62 & read(n+1)==82 & read(n+11)==36
node3=read(n+15)
temperature_node3 = [read(n+23)*256+read(n+22)]/13

node1=read(n+33)
temperature_node1 = [read(n+41)*256+read(n+40)]/13

fprintf(file,'Node %d',node3);
fprintf (file,' temperature is %2.2f C\n',temperature_node3);

fprintf(file,'Node %d',node1);
fprintf (file,' temperature is %2.2f C\n',temperature_node1);


end


if read(n)==62 & read(n+1)==82 & read(n+11)==18

node2=read(n+15)
temperature_node2 = [read(n+23)*256+read(n+22)]/13


fprintf(file,'Node %d',node2);
fprintf (file,' temperature is %2.2f C\n',temperature_node2);

end

end

%save 17Dec2016.txt formatted_temperature -ascii -append
end