ser=serial('com7');
file = fopen('31Dec2016.txt','w');
fopen(ser);
while 1
read=fread(ser);
for n = 1:470
if read(n)==62 & read(n+1)==82 & read(n+11)==36 & read(n+15) ==3 %n = 62 is <, n+1=82 is R, n+11 = 36 is rxfifocount, n+15 = data sequence used as node id
node3=read(n+15)
temperature_node3_adc_volts = [[read(n+23)*256+read(n+22)]*(3.3/1024)];
temperature_node3_trendline = [(-6.9057*temperature_node3_adc_volts*temperature_node3_adc_volts)+(45.557*temperature_node3_adc_volts)-10.626]



Humidity_node3_adc_volt = [[read(n+25)*256+read(n+24)]*(3.3/1024)];
Humidity_node3_trendline = (30.855*Humidity_node3_adc_volt)-11.504

Methane_node3_adc_count = [read(n+27)*256+read(n+26)];
Methane_node3_adc_volt	= [Methane_node3_adc_count*(3.3/1024)];
calibration_factor_for_methane_node3 = [(Methane_node3_adc_volt*2) - 1.79]; % multiplication by 2 is needed as resistor devider is used at adc pin, actual sensor voltage = 2 x adc voltage 
% and 1.79 is output of that sensor used for calibration in lab and denotes value when methane is absent)
methane_node3_sensor_volts = [[Methane_node3_adc_volt*2]-calibration_factor_for_methane_node3];

if methane_node3_sensor_volts <=1.8
methane_node3_ppm_trendline = 0
elseif 1.8 <= methane_node3_sensor_volts <= 2
methane_node3_ppm_trendline =(5095.7*methane_node3_sensor_volts*methane_node3_sensor_volts)-(17237*methane_node3_sensor_volts)+14536
else
methane_node3_ppm_trendline = 43.131*exp(1.0418*methane_node3_sensor_volts)
end




node1=read(n+33) %n+33 = data sequence used as node id
temperature_node1_adc_volts = [[read(n+41)*256+read(n+40)]*(3.3/1024)];
temperature_node1_trendline = [(-6.9057*temperature_node1_adc_volts*temperature_node1_adc_volts)+(45.557*temperature_node1_adc_volts)-10.626]


Humidity_node1_adc_volt = [[read(n+43)*256+read(n+42)]*(3.3/1024)];
Humidity_node1_trendline = (30.855*Humidity_node1_adc_volt)-11.504





fprintf(file,'Node 3');
fprintf (file,' temperature is %2.2f C\n',temperature_node3_trendline);
fprintf (file,'Humidity is %2.2f percent\n',Humidity_node3_trendline);
fprintf (file,'Methane Concentration is %2.2f ppm\n',methane_node3_ppm_trendline);

fprintf(file,'Node %d',node1);
fprintf (file,' temperature is %2.2f C\n',temperature_node1_trendline);
fprintf (file,'Humidity is %2.2f percent\n',Humidity_node1_trendline);

end


if read(n)==62 & read(n+1)==82 & read(n+11)==18	%n = 62 is <, n+1=82 is R, n+11 = 18 is rxfifocount

node2=read(n+15)
temperature_node2_adc_volts = [[read(n+23)*256+read(n+22)]*(3.3/1024)];
temperature_node2_trendline = [(-6.9057*temperature_node2_adc_volts*temperature_node2_adc_volts)+(45.557*temperature_node2_adc_volts)-10.626]

Humidity_node2_adc_volt = [[read(n+25)*256+read(n+24)]*(3.3/1024)];
Humidity_node2_trendline = (30.855*Humidity_node2_adc_volt)-11.504




fprintf(file,'Node %d',node2);
fprintf (file,' temperature is %2.2f C\n',temperature_node2_trendline);
fprintf (file,'Humidity is %2.2f percent\n',Humidity_node2_trendline);

end

end

%save 17Dec2016.txt formatted_temperature -ascii -append
end