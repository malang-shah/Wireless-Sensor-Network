ser=serial('com3')
ser
fopen(ser)
ser.RecordDetail = 'verbose';
ser.RecordName = 'MySerialFile.txt';
record(ser,'on')
fread(ser)
record(ser,'off')
fclose(ser)
