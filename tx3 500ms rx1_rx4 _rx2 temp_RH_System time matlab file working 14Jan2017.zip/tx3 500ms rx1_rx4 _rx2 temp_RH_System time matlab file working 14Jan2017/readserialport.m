ser=serial('com8')
file = fopen('node4_13Nov2016.txt','w');
while 1
fopen(ser)
fread(ser)
adc=fread(ser,203)
fclose(ser)

Local_Node = adc(119)

Node = adc(119)
temperature = [adc(127)*256+adc(126)]/13

fprintf(file,'Local Node %d',Local_Node);
fprintf(file,' Node %d',Node);
fprintf (file,' temperature is %2.2f C\n',temperature);
%save 11Nov2016_2.txt formatted_temperature -ascii -append
end